/*programa: suma números enteros con punteros
  autor: Santiago Quintero
  fecha:04/03/2019
*/
#include <stdio.h>


int main() 
{
	int a,b,s;
	int *p=&a;
	int *q=&b;
	int *r=&s;
	
	fflush(stdin);
	printf("Ingrese dos numeros enteros para realizar la suma\n");
	scanf("%d\n",p);
	scanf("%d\n",q);
	*r=*p+*q;
	printf("%d + %d = %d\n",*p,*q,*r);
	printf("TABLA DE DIRECCION DE MEMORIA\n");
	printf("%d=%p\n %d=%p\n %d=%p",*p,p,*q,q,*r,r);
	
	return 0;
}

